package com.API.user;

class RegistrationResponse {

    String result;
    public RegistrationResponse(String result){
        this.result = result;
    }

    public String getRegistrationResponse(){
        return this.result;
    }
    public void setRegistrationResponse(String result){
        this.result = result;
    }
}