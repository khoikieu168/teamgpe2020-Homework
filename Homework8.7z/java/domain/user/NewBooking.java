package domain.user;


import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class NewBooking {

    String booking_id;
    String booking_date;
    String valid_from;
    String valid_to;
    String court;
    String city_id;
    String centre_id;
    String customer;

}
