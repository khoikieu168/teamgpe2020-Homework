package domain.user;



//@Value
//@Builder
public class User {

    String id;
    String login;
    String password;
    public User(String id, String login, String password){
        this.id = id;
        this.login = login;
        this.password = password;
    }
    public static class Builder{
        String id;
        String login;
        String password;
        public Builder setId(String Id){
            this.id = id;
            return this;
        }
        public Builder setLogin(String login){
            this.login = login;
            return this;
        }
        public Builder setPassword(String password){
            this.password = password;
            return this;
        }
        public User build(){
            return new User(id, login, password);
        }
    }
}