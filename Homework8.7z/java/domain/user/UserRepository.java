package domain.user;

public interface UserRepository {

    String create(NewBooking booking);
}

