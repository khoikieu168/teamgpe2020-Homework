package domain.user;



//@AllArgsConstructor
public class UserService implements UserRepository{

    public static UserService getUserService(){
        return new UserService();
    }
    public String create(NewBooking booking) {
        String rm = ProcedureStorage.createBooking(
                booking.getBooking_id(), booking.getBooking_date(), booking.getValid_from()
                , booking.getValid_to(), booking.getCourt(), booking.getCity_id()
                , booking.getCentre_id(), booking.getCustomer());
        return rm;
    }

}
